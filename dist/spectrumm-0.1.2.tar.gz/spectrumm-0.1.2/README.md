# Spectrumm



A wrapper between pythons matplotlib and the terminal. Allows you to plot audiofiles quickly.



## Installation

`pip install spectrumm`